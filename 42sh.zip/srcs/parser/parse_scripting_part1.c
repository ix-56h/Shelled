/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_scripting.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niguinti <0x00fi@protonmail.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/30 12:13:03 by niguinti          #+#    #+#             */
/*   Updated: 2020/01/30 12:13:04 by niguinti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

t_node	*parse_for_clause(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_name(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_in(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_wordlist(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_case_clause(t_sh *sh)
{
	(void)sh;
	return (NULL);
}
