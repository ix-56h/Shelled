/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_scripting_part2.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niguinti <0x00fi@protonmail.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/30 12:14:04 by niguinti          #+#    #+#             */
/*   Updated: 2020/01/30 12:14:11 by niguinti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

t_node	*parse_case_list_ns(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_case_list(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_case_item_ns(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_case_item(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_pattern(t_sh *sh)
{
	(void)sh;
	return (NULL);
}
