/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_scripting_part3.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niguinti <0x00fi@protonmail.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/30 12:14:43 by niguinti          #+#    #+#             */
/*   Updated: 2020/01/30 12:14:44 by niguinti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

t_node	*parse_if_clause(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_else_part(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_while_clause(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_until_clause(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_function_definition(t_sh *sh)
{
	(void)sh;
	return (NULL);
}
