/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_scripting_part4.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: niguinti <0x00fi@protonmail.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/30 12:15:03 by niguinti          #+#    #+#             */
/*   Updated: 2020/02/24 16:18:28 by niguinti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

t_node	*parse_function_body(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_fname(t_sh *sh)
{
	(void)sh;
	return (NULL);
}

t_node	*parse_do_group(t_sh *sh)
{
	(void)sh;
	return (NULL);
}
